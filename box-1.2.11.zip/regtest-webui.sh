#!/bin/bash
# 回归测试: box webui cgi (订间填写页)
set -u
SRC=/vol1/@appdata/trim.hermes/workspace/boxsrc
D=/tmp/wt/data/adb/box
API=$D/webui/cgi-bin/api

bash -n "$SRC/box/webui/cgi-bin/api" && echo 'syntax OK'
cp "$SRC/box/webui/cgi-bin/api" "$API"
sed -i '1s|^#!/system/bin/sh$|#!/bin/sh|' "$API"
chmod 755 "$API"

T=9c7ff1893f6f3aa1eadd94f444983896
post() { # $1=body
  local body="$1" len
  len=${#body}
  BOX_DIR_OVERRIDE=$D REQUEST_METHOD=POST CONTENT_LENGTH=$len "$API" <<< "$body" 2>/dev/null
}
h1() { grep -oE '<h1>[^<]*' | head -1; }

echo "== 回归 =="
B="token=$T&action=saveupdate&url=https%3A%2F%2Fapi.x-max.dev%2Flink%2F2wYsProFuCMed9Mw%3Fsub%3D3"
echo "1) saveupdate: $(post "$B" | h1)"
grep '^subscription_url_mihomo=' "$D/settings.ini"

B="token=$T&action=save&url=https%3A%2F%2Fexample.com%2Fs%3Ft%3D9"
echo "2) save: $(post "$B" | h1)"

B="token=$T&action=update"
echo "3) update: $(post "$B" | h1)"

B='token=$T&action=save&url=https%3A%2F%2Fa.com%2F%22%3Btouch%20%2Ftmp%2Fwt%2Fpwned3%3B%20echo%20%22'
B=$(eval echo "$B")
echo "4) 注入拒绝行数: $(post "$B" | grep -c '不合法')"
if [ -e /tmp/wt/pwned3 ]; then echo '有洞!'; else echo '注入未发生-安全'; fi

B="token=BAD&action=save&url=https%3A%2F%2Fa.com%2F1"
echo "5) 错token拒绝行数: $(post "$B" | grep -c '安全校验失败')"

echo -n '6) settings.ini 可 source: '
bash -c "source $D/settings.ini >/dev/null 2>&1 && echo OK"

echo -n '7) GET form 状态块: '
BOX_DIR_OVERRIDE=$D REQUEST_METHOD=GET QUERY_STRING='action=form' "$API" 2>/dev/null | grep -c '当前状态'

echo -n '8) GET form 面板端口: '
BOX_DIR_OVERRIDE=$D REQUEST_METHOD=GET QUERY_STRING='action=form' "$API" 2>/dev/null | grep -oE '127.0.0.1:[0-9]+/ui/' | head -1

echo -n '9) GET form 静态入口(index.html 由 httpd 直接服务): '
curl -s --max-time 4 http://127.0.0.1:9099/index.html -o /dev/null -w '%{http_code}\n' 2>/dev/null || echo 'httpd未跑,跳过'
