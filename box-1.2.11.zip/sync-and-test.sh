#!/bin/bash
# 同步最新 api 到测试环境并跑回归
set -e
SRC=/vol1/@appdata/trim.hermes/workspace/boxsrc/box/webui/cgi-bin/api
DST=/tmp/wt/data/adb/box/webui/cgi-bin/api
cp -f "$SRC" "$DST"
sed -i '1s|^#!/system/bin/sh$|#!/bin/sh|' "$DST"
chmod 755 "$DST"
echo "副本 field() 数: $(grep -c 'field()' "$DST")"
echo "副本 md5: $(md5sum "$DST" | cut -d' ' -f1)"
bash /vol1/@appdata/trim.hermes/workspace/boxsrc/regtest-webui.sh 2>&1 | tail -14
